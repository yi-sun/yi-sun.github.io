require('igraph')
require('FNN')

#' Normalize a vector to have unit l1 norm
#' @param x a numeric vector to be normalized
#' @return a vector of same length as x but normalized.
nv <- function(x){x/sum(x)}

#' Normalize a vector to the unit interval
#' @param x a numeric vector to be normalized
#' @return a scaled vector of same length as x lying in [0,1]
rv = function(x){(x-min(x))/(max(x)-min(x))}

require('Rcpp')
require('inline')

knnsampler.code ='
Rcpp::NumericMatrix ckn(kn);
Rcpp::NumericVector cknlim(knlim);
int j = as<int>(jinit);
int clen = as<int>(len);
int cnrow = ckn.nrow();
int cncol = ckn.ncol();
Rcpp::NumericVector csamp(cnrow);
for(int i=0; i < clen;i++){
   int kl = cknlim[j];
   int jn = rand() % kl;
   j = ckn(j,jn)-1;
   csamp[j]++;
}
return csamp;
'

#' Run a discrete simple random walk on a K-nn graph
#' @param kn a matrix of size (number of nodes,K) encoding nearest neighbors
#' @param knlim a vector of size number of nodes identically of K
#' @param jinit the initial location of the sampler
#' @param len the number of sampels to draw
#' @return vector of length equal to number of nodes encoding time the walk spent at each entry
knnsampler <- cxxfunction(signature(kn="numeric",knlim="numeric",jinit="integer",len="integer"),knnsampler.code,plugin="Rcpp",includes="#include <stdlib.h>")

knnsampler.id.code ='
Rcpp::NumericMatrix ckn(kn);
Rcpp::NumericVector cknlim(knlim);
int j = as<int>(jinit);
int clen = as<int>(len);
int cnrow = ckn.nrow();
int cncol = ckn.ncol();
for(int i=0; i < clen;i++){
   int kl = cknlim[j];
   int jn = rand() % kl;
   j = ckn(j,jn)-1;
}
Rcpp::NumericVector tr(1);
tr[0]=j;
return tr;
'

#' Run a discrete simple random walk on a K-nn graph
#' @param kn a matrix of size (number of nodes,K) encoding nearest neighbors
#' @param knlim a vector of size number of nodes identically of K
#' @param jinit the initial location of the sampler
#' @param len the number of sampels to draw
#' @return vector of length equal to number of nodes encoding time the walk spent at each entry
knnsampler.id <- cxxfunction(signature(kn="numeric",knlim="numeric",jinit="integer",len="integer"),knnsampler.id.code,plugin="Rcpp",includes="#include <stdlib.h>")




mknnsampler <- function(kgraph,n,nrun=10){
  targets = sample(0:(nrow(kgraph[[1]])-1),nrun)
  lp=lapply(1:nrun,function(i){
    ks=knnsampler(kgraph[[1]],kgraph[[2]],targets[i],floor(n)+1)
    ks
  })
  Reduce('+',lp)+1
}
  

#' Make a k-nearest neighbor graph
makeKNNG <- function(x,k){
  gk=get.knn(x,k)
  list(gk[[1]], rep(k,nrow(x)),gk[[2]])
}

knnDens <- function(x,k,kg){
  y=-(ncol(x))*log(kg[[3]][,k])
  #nv(exp( y - mean(y)))
}



###
knnsampler.list.code ='
Rcpp::List ckn(kn);
int j = as<int>(jinit);
int clen = as<int>(len);
int cnrow = ckn.size();
Rcpp::NumericVector csamp(cnrow);
for(int i=0; i < clen;i++){
   SEXP tmp = ckn[j];
   Rcpp::NumericVector nexts(tmp);
   int kl = nexts.size();
   if(kl > 0){
     int jn = rand() % kl;
     j = nexts(jn)-1;
     csamp[j]++;
   }else{
     j = 0;
   }
}
return csamp;
'

#' Run a discrete simple random walk on a K-nn graph
#' @param kn a matrix of size (number of nodes,K) encoding nearest neighbors
#' @param jinit the initial location of the sampler
#' @param len the number of sampels to draw
#' @return vector of length equal to number of nodes encoding time the walk spent at each entry
knnsampler.list <- cxxfunction(signature(kn="numeric",jinit="integer",len="integer"),knnsampler.list.code,plugin="Rcpp",includes="#include <stdlib.h>")

knnsampler.id.list.code ='
Rcpp::List ckn(kn);
int j = as<int>(jinit);
int clen = as<int>(len);
int cnrow = ckn.size();
for(int i=0; i < clen;i++){
   SEXP tmp = ckn[j];
   Rcpp::NumericVector nexts(tmp);
   int kl = nexts.size();
   if(kl > 0){
     int jn = rand() % kl;
     j = nexts(jn)-1;
   }else{
     j = 0;
   }
}
Rcpp::NumericVector tr(1);
tr[0]=j;
return tr;
'

#' Run a discrete simple random walk on a K-nn graph
#' @param kn a matrix of size (number of nodes,K) encoding nearest neighbors
#' @param jinit the initial location of the sampler
#' @param len the number of sampels to draw
#' @return vector of length equal to number of nodes encoding time the walk spent at each entry
knnsampler.id.list <- cxxfunction(signature(kn="numeric",jinit="integer",len="integer"),knnsampler.id.list.code,plugin="Rcpp",includes="#include <stdlib.h>")

mknnsampler.list <- function(nbs,n,nrun=10){
  nblen = sapply(nbs,length)
  targets = sample((which(nblen > 1)-1),nrun)
  lp=lapply(1:nrun,function(i){
    ks=knnsampler.list(nbs,targets[i],floor(n)+1)
    ks
  })
  Reduce('+',lp)+1
}

require('igraph')

alamEst <- function(x,k,kg){
  ig = graph.edgelist(do.call(rbind,lapply(1:nrow(kg[[1]]),function(i){cbind(i,kg[[1]][i,])})))
  rc=sapply(1:nrow(x),function(i){
    sum((x[kg[[1]][i,],1] - x[i,1])>0) - sum((x[kg[[1]][i,],1] - x[i,1])<0) 
  })
  anc = 1
  sps=get.shortest.paths(ig,anc,mode='out')
  sapply(sps[[1]],function(i){sum(sign(diff(x[i,1]))*rc[i[-1]])}) * 2 / k
}
